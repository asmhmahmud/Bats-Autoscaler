data;

graph_init;

markerSize = 14;
markerGap = 2;

equSC = csvread('EqlSC.csv',1,3) ;
%equSC = equSC(1:timeSlots,1);

optOffline = csvread('OptOffline.csv',1,3) ;
optOffline = optOffline (1:timeSlots,:);

reactSC= csvread('ReactSC.csv',1,3) ;
reactSC = reactSC (1:timeSlots,:);

%optOffline = ones(48,10);
%impv_xlim = [min(allV),max(allV)];
impv_xlim = [1, timeSlots];
equSCName = 'EqualSC';
optOfflineName='OptOffline';
reactSCName = 'ReactSC';
hold off;



h1 = figure(1);
ourAlgRespTimes = responseTime(:,ourAlg_index).*0.001;
equSCRespTime= equSC(1:timeSlots,respIndex).*0.001;
optOffRespTime= optOffline(1:timeSlots,respIndex).*0.001;
reactSCRespTime= reactSC(1:timeSlots,respIndex).*0.001;

plot([1:timeSlots],cummean(ourAlgRespTimes), '-b','LineWidth',line_width);
hold all;
plot([1:timeSlots],cummean(equSCRespTime), '--r','LineWidth',line_width+1);
hold all;
tempOptOffResp = cummean(optOffRespTime);
plot([1:markerGap:timeSlots],tempOptOffResp(1:markerGap:end), '-.k*','LineWidth',line_width+1,'MarkerSize',markerSize);

hold all;
tempRCTOffResp = cummean(reactSCRespTime);
plot([1:markerGap:timeSlots],tempRCTOffResp(1:markerGap:end), '-.b^','LineWidth',line_width+1,'MarkerSize',markerSize);


hleg = legend(ourAlg,equSCName,optOfflineName,reactSCName,'Location','NorthEast');
set(hleg);



xlabel('Time Slot','FontSize',font_size);
ylabel(yLabelAvg,'FontSize',font_size);
xlim(impv_xlim);
ylim([0.3, 2]);
print(h1,print_pic_format,'graphs\fig_comp_delay');

ourAlgInstances= vmInstances(:,ourAlg_index).* instancePrice;
equSCInstances= equSC(1:timeSlots,vmInstIndex).* instancePrice;
optOffInstances= optOffline(1:timeSlots,vmInstIndex).* instancePrice;
reactSCInstances= reactSC(1:timeSlots,vmInstIndex).* instancePrice;
% equSCBudDef = ones(1,timeSlots ).* ceil( totalBudget/ (timeSlots*instancePrice)).*instancePrice - totalBudget/timeSlots ;
% 
% optOffBudDef = optOffline(:,1).* instancePrice - totalBudget/timeSlots;
% reactSCBudDef = reactSC(:,1).* instancePrice - totalBudget/timeSlots;



h2 = figure(2);



plot([1:timeSlots],cummean(ourAlgInstances), '-b','LineWidth',line_width);
hold all;
plot([1:timeSlots],cummean(equSCInstances), '--r','LineWidth',line_width+1);
hold all;
tempOptOffInst = cummean(optOffInstances);
plot([1:markerGap:timeSlots],tempOptOffInst(1:markerGap:end), '-.k*','LineWidth',line_width+1,'MarkerSize',markerSize);
hold all;
tempOptRCInst = cummean(reactSCInstances);
plot([1:markerGap:timeSlots],tempOptRCInst(1:markerGap:end), '-.b^','LineWidth',line_width+1,'MarkerSize',markerSize);

%hleg = legend(ourAlg,equSCName,reactSCName,'Location','SouthEast');
hleg = legend(ourAlg,equSCName,optOfflineName,reactSCName,'Location','SouthEast');
set(hleg);

xlabel('Time Slot','FontSize',font_size);
ylabel('Average Cost ($)','FontSize',font_size);
xlim(impv_xlim);
ylim([0, .3]);
% ylim([80, 600]);
% set(gca,'XTickLabel',num2str(allV)');
print(h2,print_pic_format,'graphs\fig_comp_cost');


h3 = figure(3);
plot([1:timeSlots],ourAlgRespTimes, '-b','LineWidth',line_width);
hold all;
plot([1:timeSlots],equSCRespTime, '--r','LineWidth',line_width+1);
hold all;
plot([1:markerGap:timeSlots],optOffRespTime(1:markerGap:end),  '-.k*','LineWidth',line_width+1,'MarkerSize',markerSize);
hold all;
plot([1:markerGap:timeSlots],reactSCRespTime(1:markerGap:end),  '-.b^','LineWidth',line_width+1,'MarkerSize',markerSize);

hleg = legend(ourAlg,equSCName,optOfflineName,reactSCName,'Location','NorthEast');
set(hleg);
xlabel('Time Slot','FontSize',font_size);
ylabel('Instantaneous Delay (sec)','FontSize',font_size);
xlim(impv_xlim);
ylim([0, 3]);
print(h3,print_pic_format,'graphs\fig_comp_inst_delay');



h4 = figure(4);
plot([1:timeSlots],ourAlgInstances, '-b','LineWidth',line_width);
hold all;
plot([1:timeSlots],equSCInstances, '--r','LineWidth',line_width+1);
hold all;
plot([1:markerGap:timeSlots],optOffInstances(1:markerGap:end), '-.k*','LineWidth',line_width+1,'MarkerSize',markerSize);
hold all;
plot([1:markerGap:timeSlots],reactSCInstances(1:markerGap:end), '-.b^','LineWidth',line_width+1,'MarkerSize',markerSize);

hleg = legend(ourAlg,equSCName,optOfflineName,reactSCName,'Location','NorthEast');
set(hleg);

xlabel('Time Slot','FontSize',font_size);
ylabel('Instantaneous Cost ($)','FontSize',font_size);
xlim(impv_xlim);
ylim([0, 0.5]);
print(h4,print_pic_format,'graphs\fig_comp_inst_cost');


clearvars ourAlgRespTimes equSCRespTime optOffRespTime ourAlgInstances equSCInstances optOffInstances
