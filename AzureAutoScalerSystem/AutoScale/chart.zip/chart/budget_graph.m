data;
graph_init;



vBudget = sum(vmInstances).*instancePrice;
budgetDef = vBudget - totalBudget;
respTimes = mean(responseTime);

total_un_budget = vBudget(end);

budget_xlim = [min(vBudget),max(vBudget)];

hold off;
%subplot(2,2,1);
h1 = figure(1);

plot(vBudget(1:end),respTimes(1:end) , '-b','LineWidth',line_width);
hold all;
plot(vBudget(1:end),respTimes(end).* ones(1, numel(vBudget)), '--r','LineWidth',line_width+1);

hleg = legend(ourAlg,endResult,'Location','NorthEast');
set(hleg);
xlabel('Users Budget ($)','FontSize',font_size);
ylabel(yLabelAvg,'FontSize',font_size);
xlim(budget_xlim);
ylim([0,4]);
% set(gca,'XTickLabel',num2str(allV)');
print(h1,print_pic_format,'graphs\fig_budget_resp');

h2 = figure(3);

plot(vBudget(1:end),zeros(1, numel(vBudget)) , '-b','LineWidth',line_width);
hold all;
plot(vBudget(1:end),total_un_budget -vBudget , '--r','LineWidth',line_width+1);

hleg = legend(ourAlg,endResult,'Location','NorthEast');
set(hleg);
xlabel('Users Budget ($)','FontSize',font_size);
ylabel('Budget Deficit ($)','FontSize',font_size);
xlim(budget_xlim);
ylim([-1,4]);
print(h2,print_pic_format,'graphs\fig_budget_def');




% 
% h2 = figure(2);
% vmInstancesmean = sum(vmInstances);
% plot(allV,vmInstancesmean(1:end-1) , '-b','LineWidth',line_width);
% hold all;
% plot(allV,vmInstancesmean(end).* ones(1, numel(allV)), '--r','LineWidth',line_width+1);
% 
% hleg = legend(ourAlg,endResult,'Location','SouthEast');
% set(hleg);
% 
% 
% 
% xlabel('V','FontSize',font_size);
% ylabel('Total VM Instance ','FontSize',font_size);
% % xlim(impv_xlim);
% % ylim([100,170]);
% % set(gca,'XTickLabel',num2str(allV)');
% print(h2,print_pic_format,'graphs\fig_v_totVM');



