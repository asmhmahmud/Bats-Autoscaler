global rowStart
addpath ../bin/debug;
addpath benchmark
addpath datafiles

rowStart = 1;


result_detail_file_name = 'expDetail.csv';

%responseResultFileName = 'cmbDelayResult_vInput.csv';



fileID = fopen(result_detail_file_name);
resultDetail =  textscan(fileID, '%s','delimiter', ',');
fclose(fileID);

%celldisp(resultDetail);




timeSlots=str2num( resultDetail{1}{4});
emplySlot = str2num(resultDetail{1}{6});
simEnable =  str2num(resultDetail{1}{8});
%simEnable =  0;
totalBudget =  str2num(resultDetail{1}{10});
instancePrice =  str2num(resultDetail{1}{12});


if(simEnable == 1)
        vmInstIndex = 1;
        vIndex = 2;
        qLengthIndex=3;
        respIndex = 4;
        bDefIndex = 5;
        fileName = resultDetail{1}{2};
else
        
        vmInstIndex = 3;
        vIndex =4;
        arrivalRateIndex = 6;
        respIndex = 7;
        
        fileName = 'CBAS.csv';
end




% timeslots=48;
% emplyslot = 1;
% simenable =  0;
allData = csvread(fileName,1,3) ;




vmInstances= getFormattedData(allData,vmInstIndex, timeSlots+emplySlot, rowStart, timeSlots);
allV = getFormattedData(allData,vIndex, timeSlots+emplySlot, rowStart,rowStart);
arrivalRates = getFormattedData(allData,3, timeSlots+emplySlot,  rowStart, timeSlots);
responseTime = getFormattedData(allData,respIndex, timeSlots+emplySlot,  rowStart,timeSlots);


%disp('here');
%responseTime = getFormattedData(allData,4, timeSlots+emplySlot,  rowStart,timeSlots) .* 0.001;

%avgThroughput = getFormattedData(allData,5, timeSlots+emplySlot,  rowStart,timeSlots);


%queueLength = getFormattedData(allData,4, timeSlots+emplySlot,  rowStart,timeSlots);

% if(simEnable==1)
    

    
allV = allV(1:end-1);
    
    
    
% else
%     
%    respDataTemp =  csvread(responseResultFileName,1,4) ;    
%    responseTime = getFormattedData(respDataTemp,1, timeSlots+emplySlot, rowStart,timeSlots);
%     
% end

%budgetDeficit = getFormattedData(allData,6, timeSlots+emplySlot,  timeSlots, timeSlots);



delayTable = csvread('RUBISRuntimeDelayTable.csv',1,0) ;






% reactSCResp = csvread('reactSC.csv',1,6) ;
% reactSCResp = reactSCResp(1:timeSlots,1);
% reactSCVM = csvread('reactSC.csv',1,3) ;
% reactSCVM = reactSCVM(1:timeSlots,1);
% 
% 
% 
% optOffResp = csvread('optOffline.csv',1,6) ;
% optOffResp = optOffResp(1:timeSlots,1);
% optOffVM = csvread('optOffline.csv',1,3) ;
% optOffVM = optOffVM(1:timeSlots,1);

   