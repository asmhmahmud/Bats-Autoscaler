data;
graph_init;


%impv_xlim = [min(allV),max(allV)];
impv_xlim = [min(allV),5];

delayTableLength = 20;
noOfItemPerCol = 4;
markerSize = 14;

inst4Resp = delayTable(4, 3:noOfItemPerCol:delayTableLength*noOfItemPerCol).*0.001;
inst4load = delayTable(4, 2:noOfItemPerCol:delayTableLength*noOfItemPerCol);
inst6Resp = delayTable(6, 3:noOfItemPerCol:delayTableLength*noOfItemPerCol).*0.001;
inst6load = delayTable(6, 2:noOfItemPerCol:delayTableLength*noOfItemPerCol);
inst8Resp = delayTable(8, 3:noOfItemPerCol:delayTableLength*noOfItemPerCol).*0.001;
inst8load = delayTable(8, 2:noOfItemPerCol:delayTableLength*noOfItemPerCol);

inst10Resp = delayTable(10, 3:noOfItemPerCol:delayTableLength*noOfItemPerCol).*0.001;
inst10load = delayTable(10, 2:noOfItemPerCol:delayTableLength*noOfItemPerCol);

inst12Resp = delayTable(12, 3:noOfItemPerCol:delayTableLength*noOfItemPerCol).*0.001;
inst12load = delayTable(12, 2:noOfItemPerCol:delayTableLength*noOfItemPerCol);

hold off;
h1 = figure(1);

plot(inst4load,inst4Resp  , '-b','LineWidth',line_width);
hold all;
plot(inst6load,inst6Resp, '--r','LineWidth',line_width+1);
hold all;
plot(inst8load,inst8Resp, '-.b*','LineWidth',line_width,'MarkerSize',markerSize);

hold all;
plot(inst10load,inst10Resp, '-.r^','LineWidth',line_width,'MarkerSize',markerSize);

hleg = legend('m =4','m =6','m =8','m =10','Location','SouthEast');
set(hleg);



xlabel('No of clients','FontSize',font_size);
ylabel('Total Average Time (sec)','FontSize',font_size);
xlim([100, 1200]);
ylim([-1,4]);
%xlim(impv_xlim);
% set(gca,'XTickLabel',num2str(allV)');
print(h1,print_pic_format,'graphs\fig_load_vs_resp');


delayGraphData = csvread('delayGraphData.csv') ;
instanceCount = [1:20];
prefix = 'cl=';

h2 = figure(2);

plot(instanceCount,delayGraphData(1,2:21)  , '-b','LineWidth',line_width);
hold all;
plot(instanceCount,delayGraphData(2,2:21), '--r','LineWidth',line_width+1);
hold all;
plot(instanceCount,delayGraphData(3,2:21),'-.b*','LineWidth',line_width,'MarkerSize',markerSize);
hold all;
 plot(instanceCount,delayGraphData(4,2:21),'-.r^','LineWidth',line_width,'MarkerSize',markerSize);

hleg = legend( strcat(prefix,num2str(delayGraphData(1,1))),strcat(prefix,num2str(delayGraphData(2,1))),strcat(prefix,num2str(delayGraphData(3,1))),strcat(prefix,num2str(delayGraphData(4,1))),'Location','NorthEast');
set(hleg);



xlabel('No of VM instances (m)','FontSize',font_size);
ylabel('Total Average Time (sec)','FontSize',font_size);
xlim([1, 10]);
ylim([-1,4]);
print(h2,print_pic_format,'graphs\fig_instance_vs_resp');



