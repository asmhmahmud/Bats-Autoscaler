function [ output ] = getDelay( delayTable, instance, arrivalRate )
output = -1;
index = 20- instance+1 ;

targetData = delayTable(index, 1:51);
tdSize = numel(targetData);
%disp(targetData);
lastSmallestIndex =1;

if(targetData(2) > arrivalRate )
    output = targetData(3);
elseif (targetData(tdSize - 1) < arrivalRate )
    output = inf;
else
    for i=4:3:tdSize
        if(targetData(i+1) >= arrivalRate )
            %disp(i);
            lastSmallestIndex = i-2;
            break;
        end
        
       
    end
                  arrival_x1 = targetData (lastSmallestIndex);
              arrival_x2 = targetData (lastSmallestIndex+3);

              delay_y1 = targetData (lastSmallestIndex+1);
               delay_y2 = targetData (lastSmallestIndex+4);

               
               
                output = delay_y1 + (arrivalRate - arrival_x1) * (delay_y2 - delay_y1) / (arrival_x2 - arrival_x1);
                disp([instance, arrival_x1, arrival_x2, delay_y1, delay_y2,output]);
    
    
    
end



end

