function [ output ] = getFormattedData( allData, targetCol, totalRowsToReshape,fromRow,  toRow )
temp_output = reshape(allData(:,targetCol), totalRowsToReshape, []);

output = temp_output(fromRow:toRow,:);

end

