
% Change default axes fonts.
font_size = 32;
leg_font_size = 20;
text_font = 32;
line_width = 3;


ourAlg = 'CBAS';
endResult = 'Budget-Unaware';

ourAlg_index =8;

%ylabel = 'Total Average Time (sec)';
yLabelAvg = 'Average Delay (sec)';


print_pic_format = '-depsc ';  %eps color
%print_pic_format = '-dpng ';  %png color


set(0,'DefaultAxesFontName', 'Arial');
set(0,'DefaultAxesFontSize', font_size);

% Change default text fonts.
set(0,'DefaultTextFontname', 'Arial');
set(0,'DefaultTextFontSize', font_size);
hold off;


