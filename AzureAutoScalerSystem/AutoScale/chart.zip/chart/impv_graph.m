data;
graph_init;


%impv_xlim = [min(allV),max(allV)];
impv_xlim = [min(allV),max(allV)];


hold off;
%subplot(2,2,1);
h1 = figure(1);
respTimes = mean(responseTime);
plot(allV,respTimes(1:end-1) , '-b','LineWidth',line_width);
hold all;
plot(allV,respTimes(end).* ones(1, numel(allV)), '--r','LineWidth',line_width+1);

hleg = legend(ourAlg,endResult,'Location','NorthEast');
set(hleg);
xlabel('V','FontSize',font_size);
ylabel(yLabelAvg,'FontSize',font_size);
xlim(impv_xlim);
%ylim([0,2.5]);
% set(gca,'XTickLabel',num2str(allV)');
print(h1,print_pic_format,'graphs\fig_v_resp');

h2 = figure(3);
budgetDef = sum(vmInstances).*instancePrice - totalBudget;
plot(allV,budgetDef(1:end-1) , '-b','LineWidth',line_width);
hold all;
plot(allV,budgetDef(end).* ones(1, numel(allV)), '--r','LineWidth',line_width+1);

hleg = legend(ourAlg,endResult,'Location','SouthEast');
set(hleg);



xlabel('V','FontSize',font_size);
ylabel('Budget Deficit ($)','FontSize',font_size);
xlim(impv_xlim);
% ylim([-8,12]);
print(h2,print_pic_format,'graphs\fig_v_def');




% 
% h2 = figure(2);
% vmInstancesmean = sum(vmInstances);
% plot(allV,vmInstancesmean(1:end-1) , '-b','LineWidth',line_width);
% hold all;
% plot(allV,vmInstancesmean(end).* ones(1, numel(allV)), '--r','LineWidth',line_width+1);
% 
% hleg = legend(ourAlg,endResult,'Location','SouthEast');
% set(hleg);
% 
% 
% 
% xlabel('V','FontSize',font_size);
% ylabel('Total VM Instance ','FontSize',font_size);
% % xlim(impv_xlim);
% % ylim([100,170]);
% % set(gca,'XTickLabel',num2str(allV)');
% print(h2,print_pic_format,'graphs\fig_v_totVM');



