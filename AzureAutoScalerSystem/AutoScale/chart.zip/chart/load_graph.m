data;
graph_init;

impv_xlim = [1, timeSlots];


load_msr = csvread('load_msr.csv') ;
load_msr = load_msr(1:timeSlots);

hold off;
h1 = figure(1);

plot([1:timeSlots],load_msr, '-b','LineWidth',line_width);
hold all;



xlabel('Time Slot','FontSize',font_size);
ylabel('Normalized Arrival Rate','FontSize',font_size);
xlim(impv_xlim);
ylim([-0.2, 1]);
print(h1,print_pic_format,'graphs\fig_load_msr');

