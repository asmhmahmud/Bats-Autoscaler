instances = [9:14];
budget = (instances .* .8 .* .02 .*48 ) ./ 11.44;
disp(budget);