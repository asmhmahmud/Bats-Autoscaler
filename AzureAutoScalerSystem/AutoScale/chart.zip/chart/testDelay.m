delay_file_name = 'runtimeDelay.csv';

delayTable =   csvread(delay_file_name,1,0) ;    
noOfTest = 1;
instances= ones(noOfTest,20);
arrivals = 390;

% for arrivals=100:20:20*noOfTest+100

for i=1:20
    instances(i) = getDelay(delayTable, i, arrivals);
end
% end

graph_init;


% for i=1:noOfTest
%     hold on;
plot(1:numel(instances(1,:)),instances , '-b','LineWidth',line_width);
% end


%ylim([1,3000]);
xlabel('Instances','FontSize',font_size);
ylabel('Response Time (ms)','FontSize',font_size);
